/*
 * Network test code.
 */
#include <types.h>
#include <lib.h>
#include <test.h>

void
nettest(void)
{
	kprintf("No network support available\n");
}
