//Phillip Robertson & Grace Tang
//Comp 3500 - Xiao Qin 
//hello.c
// References: C STD LIBRARY - http://en.wikipedia.org/wiki/C_standard_library


void hello(){
	kprintf("Hello World\n");

}
